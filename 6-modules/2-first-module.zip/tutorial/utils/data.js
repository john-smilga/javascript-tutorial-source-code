export const random = 'random value';

export const people = [
  { name: 'john', job: 'developer' },
  { name: 'susan', job: 'designer' },
  { name: 'anna', job: 'the boss' },
];
