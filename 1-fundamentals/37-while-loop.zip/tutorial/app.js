// Loops
// repeatedly run a block of code while condition is true
// while loop
// TURN OFF AUTOSAVE

let amount = 10;

while (amount > 0) {
  console.log('I have ' + amount + " dollars and I'm going to the mall");
  amount--;
}
