// Loops
// repeatedly run a block of code while condition is true
// do while loop
// code block first, condition second
// runs at least

let money = 12;

do {
  console.log('You have ' + money + ' dollars');
  money++;
} while (money < 10);
