// "" or ''
const name = "john's courses are the best";

console.log(name);
