// Arrays, Functions and Objects
// Functions - declare, invoke

function hello() {
  // logic
  console.log('Hello There Bob');
  console.log('Hello There Anna');
  console.log('Hello There Susy');
}

hello();
// come code here....
hello();
// come code here....
hello();
// come code here....
