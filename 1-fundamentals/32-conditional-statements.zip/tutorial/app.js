// Conditional Statements
// >, <, >=, <=, ==, ===, !=, !===

const value = 2 > 1;
// console.log(typeof value);
const value2 = 1 > 2;
if (value2) {
  console.log('hello world');
} else {
  console.log('hello people');
}
