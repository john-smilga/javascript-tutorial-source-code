// Arrays, Functions and Objects
// return
// default undefined, shortcuts, ignores after
// 1 inch 2.54cm
const wallHeight = 80;

function calculate(value) {
  // const newValue = value * 2.54;
  return value * 2.54;
  console.log('hello');
  console.log('hello');
  console.log('hello');
}

calculate(200);
const width = calculate(100);
const height = calculate(wallHeight);

const dimensions = [width, height];
console.log(dimensions);
