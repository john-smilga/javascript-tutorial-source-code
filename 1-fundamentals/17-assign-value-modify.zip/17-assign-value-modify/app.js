// Variable - Most Basic Building Block
// Variables - Store, Access, Modify === Value
// Declare, Assignment Operator, Assign Value
// assign value later, modify existing
let name = "john shrimp taco VI";
let address, zip, state;
address = "101 main street";
zip = "60612";
state = "CA";
name = "fish burrito ";
console.log(address, zip, state);
console.log(name);
