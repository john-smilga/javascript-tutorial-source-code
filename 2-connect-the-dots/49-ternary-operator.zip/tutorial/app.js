// unary operator -  typeof
let text = 'some text';
// console.log(typeof text); // operand
// binary operator - assignment
let number = 3;
let number2 = 2 + 5;
// ternary operator
// condition ? (runs if true) : (runs if false)

const value = 1 < 0;

value ? console.log('value is true') : console.log('value is false');

// if (value) {
//   console.log('value is true');
// } else {
//   console.log('value is false');
// }
