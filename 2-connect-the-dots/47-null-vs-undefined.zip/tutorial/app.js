// Truthy and Falsy
// "",'',``,0 ,-0 ,NaN ,false, null, undefined
