// null and undefined
// both represent "no value"

// undefined - "javascript cannot find a value for this"

// variable without value
// missing function arguments
// missing object properties

// null - "developer sets the value"

const number = 20 + null; //20 + 0 = 20
console.log(number);

const number2 = 20 + undefined; //Not a number
console.log(number2);
